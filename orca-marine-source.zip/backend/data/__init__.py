# Init for data module
